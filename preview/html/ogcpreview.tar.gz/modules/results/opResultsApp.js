angular.module('opApp', [
    'ngResource',
    'ngSanitize',
    'ngAnimate',
    'ui.bootstrap'
]);