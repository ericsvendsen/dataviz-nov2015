angular.module('opApp').directive('opMap', function () {
    'use strict';

    return {
        scope: {},
        restrict: 'E',
        templateUrl: 'modules/map/opMap.html'
    };
});