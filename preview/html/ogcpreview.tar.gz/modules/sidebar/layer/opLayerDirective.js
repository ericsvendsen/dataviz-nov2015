angular.module('opApp').directive('opLayer', function () {
    'use strict';

    return {
        scope: {},
        restrict: 'E',
        templateUrl: 'modules/sidebar/layer/opLayerSelect.html'
    };
});

